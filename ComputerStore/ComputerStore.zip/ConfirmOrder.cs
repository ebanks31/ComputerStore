﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComputerStore
{
    public partial class ConfirmOrder : Form
    {
        public ConfirmOrder()
        {
            InitializeComponent();
        }

        private void ConfirmOrder_Load(object sender, EventArgs e)
        {

        }

        private void ConfirmOrder_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Yesbutton_Click(object sender, EventArgs e)
        {

        }

        private void Nobutton_Click(object sender, EventArgs e)
        {

        }

        private void Yesbutton_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void Nobutton_MouseHover(object sender, EventArgs e)
        {

        }
    }
}
