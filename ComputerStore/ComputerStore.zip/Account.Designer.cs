﻿namespace ComputerStore
{
    partial class Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordtextBox1 = new System.Windows.Forms.TextBox();
            this.emailpasswordtextBox2 = new System.Windows.Forms.TextBox();
            this.addresstextBox3 = new System.Windows.Forms.TextBox();
            this.phonenumbertextBox4 = new System.Windows.Forms.TextBox();
            this.ChangePasswordButton = new System.Windows.Forms.Button();
            this.ChangeEmailButton = new System.Windows.Forms.Button();
            this.PhoneNumberbutton = new System.Windows.Forms.Button();
            this.changeaddressbutton4 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.optionToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(539, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // optionToolStripMenuItem
            // 
            this.optionToolStripMenuItem.Name = "optionToolStripMenuItem";
            this.optionToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.optionToolStripMenuItem.Text = "Option";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 337);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(539, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 208);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "label4";
            // 
            // passwordtextBox1
            // 
            this.passwordtextBox1.Location = new System.Drawing.Point(154, 68);
            this.passwordtextBox1.Name = "passwordtextBox1";
            this.passwordtextBox1.Size = new System.Drawing.Size(100, 20);
            this.passwordtextBox1.TabIndex = 6;
            // 
            // emailpasswordtextBox2
            // 
            this.emailpasswordtextBox2.Location = new System.Drawing.Point(154, 109);
            this.emailpasswordtextBox2.Name = "emailpasswordtextBox2";
            this.emailpasswordtextBox2.Size = new System.Drawing.Size(100, 20);
            this.emailpasswordtextBox2.TabIndex = 7;
            // 
            // addresstextBox3
            // 
            this.addresstextBox3.Location = new System.Drawing.Point(154, 156);
            this.addresstextBox3.Name = "addresstextBox3";
            this.addresstextBox3.Size = new System.Drawing.Size(100, 20);
            this.addresstextBox3.TabIndex = 8;
            // 
            // phonenumbertextBox4
            // 
            this.phonenumbertextBox4.Location = new System.Drawing.Point(154, 208);
            this.phonenumbertextBox4.Name = "phonenumbertextBox4";
            this.phonenumbertextBox4.Size = new System.Drawing.Size(100, 20);
            this.phonenumbertextBox4.TabIndex = 9;
            // 
            // ChangePasswordButton
            // 
            this.ChangePasswordButton.Location = new System.Drawing.Point(293, 68);
            this.ChangePasswordButton.Name = "ChangePasswordButton";
            this.ChangePasswordButton.Size = new System.Drawing.Size(107, 23);
            this.ChangePasswordButton.TabIndex = 10;
            this.ChangePasswordButton.Text = "Change Password";
            this.ChangePasswordButton.UseVisualStyleBackColor = true;
            this.ChangePasswordButton.Click += new System.EventHandler(this.ChangePasswordButton_Click);
            this.ChangePasswordButton.MouseHover += new System.EventHandler(this.ChangePasswordButton_MouseHover);
            // 
            // ChangeEmailButton
            // 
            this.ChangeEmailButton.Location = new System.Drawing.Point(293, 109);
            this.ChangeEmailButton.Name = "ChangeEmailButton";
            this.ChangeEmailButton.Size = new System.Drawing.Size(107, 23);
            this.ChangeEmailButton.TabIndex = 11;
            this.ChangeEmailButton.Text = "Change Email";
            this.ChangeEmailButton.UseVisualStyleBackColor = true;
            this.ChangeEmailButton.Click += new System.EventHandler(this.ChangeEmailButton_Click);
            this.ChangeEmailButton.MouseHover += new System.EventHandler(this.ChangeEmailButton_MouseHover);
            // 
            // PhoneNumberbutton
            // 
            this.PhoneNumberbutton.Location = new System.Drawing.Point(293, 205);
            this.PhoneNumberbutton.Name = "PhoneNumberbutton";
            this.PhoneNumberbutton.Size = new System.Drawing.Size(134, 23);
            this.PhoneNumberbutton.TabIndex = 12;
            this.PhoneNumberbutton.Text = "Change Phone Number";
            this.PhoneNumberbutton.UseVisualStyleBackColor = true;
            this.PhoneNumberbutton.Click += new System.EventHandler(this.PhoneNumberbutton_Click);
            this.PhoneNumberbutton.MouseHover += new System.EventHandler(this.PhoneNumberbutton_MouseHover);
            // 
            // changeaddressbutton4
            // 
            this.changeaddressbutton4.Location = new System.Drawing.Point(293, 158);
            this.changeaddressbutton4.Name = "changeaddressbutton4";
            this.changeaddressbutton4.Size = new System.Drawing.Size(115, 23);
            this.changeaddressbutton4.TabIndex = 13;
            this.changeaddressbutton4.Text = "Change Address";
            this.changeaddressbutton4.UseVisualStyleBackColor = true;
            this.changeaddressbutton4.Click += new System.EventHandler(this.changeaddressbutton4_Click);
            this.changeaddressbutton4.MouseHover += new System.EventHandler(this.changeaddressbutton4_MouseHover);
            // 
            // Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 359);
            this.Controls.Add(this.changeaddressbutton4);
            this.Controls.Add(this.PhoneNumberbutton);
            this.Controls.Add(this.ChangeEmailButton);
            this.Controls.Add(this.ChangePasswordButton);
            this.Controls.Add(this.phonenumbertextBox4);
            this.Controls.Add(this.addresstextBox3);
            this.Controls.Add(this.emailpasswordtextBox2);
            this.Controls.Add(this.passwordtextBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Account";
            this.Text = "Account";
            this.Load += new System.EventHandler(this.Account_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox passwordtextBox1;
        private System.Windows.Forms.TextBox emailpasswordtextBox2;
        private System.Windows.Forms.TextBox addresstextBox3;
        private System.Windows.Forms.TextBox phonenumbertextBox4;
        private System.Windows.Forms.Button ChangePasswordButton;
        private System.Windows.Forms.Button ChangeEmailButton;
        private System.Windows.Forms.Button PhoneNumberbutton;
        private System.Windows.Forms.Button changeaddressbutton4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}