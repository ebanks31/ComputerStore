﻿namespace ComputerStore
{
    partial class Admin_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminLogin = new System.Windows.Forms.Button();
            this.usernametextbpx = new System.Windows.Forms.TextBox();
            this.passwordtextbpx = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CustomerOptionsbutton = new System.Windows.Forms.Button();
            this.AddUserButton = new System.Windows.Forms.Button();
            this.ProductOptions = new System.Windows.Forms.Button();
            this.SQLbutton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // AdminLogin
            // 
            this.AdminLogin.Location = new System.Drawing.Point(302, 212);
            this.AdminLogin.Name = "AdminLogin";
            this.AdminLogin.Size = new System.Drawing.Size(75, 23);
            this.AdminLogin.TabIndex = 0;
            this.AdminLogin.Text = "Admin Login";
            this.AdminLogin.UseVisualStyleBackColor = true;
            // 
            // usernametextbpx
            // 
            this.usernametextbpx.Cursor = System.Windows.Forms.Cursors.Default;
            this.usernametextbpx.Location = new System.Drawing.Point(264, 118);
            this.usernametextbpx.Name = "usernametextbpx";
            this.usernametextbpx.Size = new System.Drawing.Size(157, 20);
            this.usernametextbpx.TabIndex = 1;
            // 
            // passwordtextbpx
            // 
            this.passwordtextbpx.Location = new System.Drawing.Point(264, 164);
            this.passwordtextbpx.Name = "passwordtextbpx";
            this.passwordtextbpx.Size = new System.Drawing.Size(157, 20);
            this.passwordtextbpx.TabIndex = 2;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 335);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(677, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.optionsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(677, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.editToolStripMenuItem1,
            this.optionsToolStripMenuItem1,
            this.helpToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(528, 24);
            this.menuStrip2.TabIndex = 0;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // editToolStripMenuItem1
            // 
            this.editToolStripMenuItem1.Name = "editToolStripMenuItem1";
            this.editToolStripMenuItem1.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem1.Text = "Edit";
            // 
            // optionsToolStripMenuItem1
            // 
            this.optionsToolStripMenuItem1.Name = "optionsToolStripMenuItem1";
            this.optionsToolStripMenuItem1.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem1.Text = "Options";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem1.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip2.Location = new System.Drawing.Point(0, 262);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(528, 22);
            this.statusStrip2.TabIndex = 1;
            this.statusStrip2.Text = "statusStrip2";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // CustomerOptionsbutton
            // 
            this.CustomerOptionsbutton.Location = new System.Drawing.Point(188, 67);
            this.CustomerOptionsbutton.Name = "CustomerOptionsbutton";
            this.CustomerOptionsbutton.Size = new System.Drawing.Size(116, 23);
            this.CustomerOptionsbutton.TabIndex = 1;
            this.CustomerOptionsbutton.Text = "Customer Options";
            this.CustomerOptionsbutton.UseVisualStyleBackColor = true;
            this.CustomerOptionsbutton.Click += new System.EventHandler(this.CustomerOptionsbutton_Click);
            this.CustomerOptionsbutton.MouseEnter += new System.EventHandler(this.CustomerOptionsbutton_MouseEnter);
            // 
            // AddUserButton
            // 
            this.AddUserButton.Location = new System.Drawing.Point(188, 112);
            this.AddUserButton.Name = "AddUserButton";
            this.AddUserButton.Size = new System.Drawing.Size(116, 23);
            this.AddUserButton.TabIndex = 2;
            this.AddUserButton.Text = "User Options";
            this.AddUserButton.UseVisualStyleBackColor = true;
            this.AddUserButton.Click += new System.EventHandler(this.AddUserButton_Click);
            this.AddUserButton.MouseEnter += new System.EventHandler(this.AddUserButton_MouseEnter);
            // 
            // ProductOptions
            // 
            this.ProductOptions.Location = new System.Drawing.Point(188, 159);
            this.ProductOptions.Name = "ProductOptions";
            this.ProductOptions.Size = new System.Drawing.Size(113, 23);
            this.ProductOptions.TabIndex = 3;
            this.ProductOptions.Text = "Product Options";
            this.ProductOptions.UseVisualStyleBackColor = true;
            this.ProductOptions.Click += new System.EventHandler(this.ProductOptions_Click);
            this.ProductOptions.MouseEnter += new System.EventHandler(this.ProductOptions_MouseEnter);
            // 
            // SQLbutton
            // 
            this.SQLbutton.Location = new System.Drawing.Point(188, 208);
            this.SQLbutton.Name = "SQLbutton";
            this.SQLbutton.Size = new System.Drawing.Size(113, 23);
            this.SQLbutton.TabIndex = 4;
            this.SQLbutton.Text = "SQL";
            this.SQLbutton.UseVisualStyleBackColor = true;
            this.SQLbutton.Click += new System.EventHandler(this.SQLbutton_Click);
            this.SQLbutton.MouseEnter += new System.EventHandler(this.SQLbutton_MouseEnter);
            // 
            // Admin_Login
            // 
            this.ClientSize = new System.Drawing.Size(528, 284);
            this.Controls.Add(this.SQLbutton);
            this.Controls.Add(this.ProductOptions);
            this.Controls.Add(this.AddUserButton);
            this.Controls.Add(this.CustomerOptionsbutton);
            this.Controls.Add(this.statusStrip2);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip2;
            this.Name = "Admin_Login";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Login_Load);
            this.MouseHover += new System.EventHandler(this.Admin_Login_MouseHover);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AdminLogin;
        private System.Windows.Forms.TextBox usernametextbpx;
        private System.Windows.Forms.TextBox passwordtextbpx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.Button CustomerOptionsbutton;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.Button AddUserButton;
        private System.Windows.Forms.Button ProductOptions;
        private System.Windows.Forms.Button SQLbutton;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}