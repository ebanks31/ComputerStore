﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComputerStore;

namespace ComputerStoreTest
{
    [TestClass]
    public class ValidateAddressUnitTest
    {
        [TestMethod]
        public void Test_ValidAddress()
        {
            Register register = new Register();
            string validaddress = "2023 john creek dr.";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(false, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_ValidPOBox()
        {
            Register register = new Register();
            string validaddress = "P.O. Box 562 ";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(false, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_InvalidAddress()
        {
            Register register = new Register();
            string validaddress = "test@gmail.com";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(true, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_InvalidAddress2()
        {
            Register register = new Register();
            string validaddress = "1223344";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(true, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_InvalidAddress3()
        {
            Register register = new Register();
            string validaddress = "ssssssssssss";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(true, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_InvalidAddress4()
        {
            Register register = new Register();
            string validaddress = "";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(true, register.NotValidAddress);
        }

        [TestMethod]
        public void Test_InvalidAddress5()
        {
            Register register = new Register();
            string validaddress = " ";
            register.ValidateAddress(validaddress);
            Assert.AreEqual(true, register.NotValidAddress);
        }
    }
}
