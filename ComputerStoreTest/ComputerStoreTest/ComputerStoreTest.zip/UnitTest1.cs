﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComputerStore;

namespace ComputerStoreTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_ValidEmailWithDashes()
    {
	Register register = new Register();
    string validemail = "test@gmail.com";
    register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
    }

        [TestMethod]
        public void Test_ValidEmail()
{
	Register register = new Register();
	string validemail = "t2@gmail.com";
	register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
}

        [TestMethod]
        public void Test_ValidEmail2()
{
	Register register = new Register();
	string validemail = "t@gmail.com";
    register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
}

        [TestMethod]
        public void Test_ValidEmail3()
{
	Register register = new Register();
    string validemail = "test@yahoo.com";
	register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
}

        [TestMethod]
        public void Test_ValidEmail4()
{
	Register register = new Register();
    string validemail = "test@hotmail.com";
	register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
}

        [TestMethod]
        public void Test_InvalidEmail()
{
	Register register = new Register();
    string validemail = "testhotmail.com";
	register.ValidateEmail(validemail);
    Assert.AreEqual(true, register.NotValidEmail);
}

        [TestMethod]
        public void Test_InvalidEmail1()
{
	Register register = new Register();
    string validemail = "hotmail.com";
	register.ValidateEmail(validemail);
    Assert.AreEqual(true, register.NotValidEmail);
}

        [TestMethod]
        public void Test_InvalidEmail2()
{
	Register register = new Register();
	string validemail = "12131@hotmail.com";
    register.ValidateEmail(validemail);
    Assert.AreEqual(false, register.NotValidEmail);
}

        [TestMethod]
        public void Test_InvalidEmail3()
        {
            Register register = new Register();
            string validemail = "@hotmail.com";
            register.ValidateEmail(validemail);
            Assert.AreEqual(true, register.NotValidEmail);
        }
    }
}
